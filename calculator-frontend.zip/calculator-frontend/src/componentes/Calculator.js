import React, { useState } from 'react';
import axios from 'axios';
import { FaPlus, FaMinus, FaTimes, FaDivide } from 'react-icons/fa';

const Calculator = () => {
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');
  const [result, setResult] = useState(null);
  const token = localStorage.getItem('token');

  const handleCalculation = async (operation) => {
    try {
      const response = await axios.get(`https://localhost:32779/api/calculator/${operation}`, {
        params: { a: num1, b: num2 },
        headers: { Authorization: `Bearer ${token}` },
      });
      setResult(response.data); // Certifique-se de que response.data contém o valor esperado
    } catch (error) {
      console.error('Erro ao calcular:', error);
      setResult('Erro ao realizar a operação'); // Exibe uma mensagem de erro
    }
  };
  

  return (
    <div className="container d-flex justify-content-center align-items-center min-vh-100" style={{ backgroundColor: '#1a1a2e' }}>
      <div className="card p-4" style={{ width: '400px' }}>
        <h2 className="text-center text-custom-color mb-4">Calculadora</h2>
        
        <div className="mb-3">
          <label className="form-label text-custom-color">Número 1:</label>
          <input
            type="number"
            className="form-control"
            value={num1}
            onChange={(e) => setNum1(e.target.value)}
          />
        </div>
        
        <div className="mb-3">
          <label className="form-label text-custom-color">Número 2:</label>
          <input
            type="number"
            className="form-control"
            value={num2}
            onChange={(e) => setNum2(e.target.value)}
          />
        </div>
        
        <h5 className="text-custom-color">
            Resultado: {result !== null && typeof result === 'number' ? result : result}
        </h5>


        <div className="d-flex justify-content-between mt-4 gap-2">
    <button className="btn btn-primary" onClick={() => handleCalculation('add')}>
        <FaPlus /> Somar
    </button>
    <button className="btn btn-warning" onClick={() => handleCalculation('subtract')}>
        <FaMinus /> Subtrair
    </button>
    <button className="btn btn-success" onClick={() => handleCalculation('multiply')}>
        <FaTimes /> Multiplicar
    </button>
    <button className="btn btn-danger" onClick={() => handleCalculation('divide')}>
        <FaDivide /> Dividir
    </button>
</div>


      </div>
    </div>
  );
};

export default Calculator;
