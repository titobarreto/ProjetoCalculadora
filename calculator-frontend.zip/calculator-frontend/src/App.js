// src/App.js

import React, { useState } from 'react';
import Login from './componentes/Login';
import Calculator from './componentes/Calculator';

function App() {
  const [token, setToken] = useState(null);

  const handleLogin = (newToken) => {
    setToken(newToken);
    localStorage.setItem('token', newToken); // Opcional: armazena o token no localStorage
  };

  const handleLogout = () => {
    setToken(null);
    localStorage.removeItem('token'); // Remove o token do localStorage
  };

  return (
    <div className="App">
      {token ? (
        <Calculator token={token} onLogout={handleLogout} />
      ) : (
        <Login onLogin={handleLogin} />
      )}
    </div>
  );
}

export default App;
